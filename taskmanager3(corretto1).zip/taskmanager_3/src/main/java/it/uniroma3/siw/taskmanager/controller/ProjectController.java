package it.uniroma3.siw.taskmanager.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.WebAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.NoHandlerFoundException;

import it.uniroma3.siw.taskmanager.controller.session.SessionData;
import it.uniroma3.siw.taskmanager.controller.validation.ProjectValidator;
import it.uniroma3.siw.taskmanager.model.Credentials;
import it.uniroma3.siw.taskmanager.model.Project;
import it.uniroma3.siw.taskmanager.model.User;
import it.uniroma3.siw.taskmanager.service.CredentialsService;
import it.uniroma3.siw.taskmanager.service.ProjectService;
import it.uniroma3.siw.taskmanager.service.UserService;


@Controller
public class ProjectController {
	
	@Autowired
	ProjectService projectService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	ProjectValidator projectValidator;
	
	@Autowired
	CredentialsService credentialsService;
	
	@Autowired
	SessionData sessionData;
	
	 /**
     * This method is called when a GET request is sent by the user to URL "/projects".
     * This method prepares and dispatches the User registration view.
     *
     * @param model the Request model
     * @return the name of the target view, that in this case is "myOwnedProjects"
     */
    @RequestMapping(value = { "/projects" }, method = RequestMethod.GET)
    public String myOwnedProjects(Model model) {
        User loggedUser = sessionData.getLoggedUser();
        List<Project> projectsList = projectService.retrieveProjectsOwnedBy(loggedUser);
        model.addAttribute("loggedUser", loggedUser);
        model.addAttribute("projectsList", projectsList);
        return "myOwnedProjects";
    }
    
    @RequestMapping(value = { "/projects/{projectId}" }, method = RequestMethod.GET)
    public String project(Model model, @PathVariable Long projectId) {
    	User loggedUser = sessionData.getLoggedUser();
    	// if no project with the passed ID exists,
    	// redirect to the view wth the list of my projects
    	Project project = projectService.getProject(projectId);
    	if(project == null)
    		return "redirect:/projects";
    	
    	//if I do not have access to any project with the passed ID, 
    	//redirect to the view with the list of my projects
    	
    	List<User> members = userService.getMembers(project);
    	if(!project.getOwner().equals(loggedUser) && !members.contains(loggedUser))
    		return "redirect:/projects";
    	
    	model.addAttribute("loggedUser", loggedUser);
    	model.addAttribute("project", project);
    	model.addAttribute("members", members);
    	
    	return "project"; 	
    }
    
    /**
     * This method is called when a GET request is sent by the user to URL "/projects/add".
     * This method prepares and dispatches a view containing the form to add a new Project..
     *
     * @param model the Request model
     * @return the name of the target view, that in this case is "addProject"
     */
    @RequestMapping(value= { "/projects/add" }, method = RequestMethod.GET)
    public String createProjectForm(Model model) {
    	User loggedUser = sessionData.getLoggedUser();
    	model.addAttribute("loggedUser", loggedUser);
    	model.addAttribute("projectForm", new Project());
    	return "addProject";
    }
    @RequestMapping(value= { "/projects/add" }, method = RequestMethod.POST)
    public String createProject(@Valid @ModelAttribute("projectForm") Project project,
    		BindingResult projectBindingResult, Model model) {
    	
    	User loggedUser = sessionData.getLoggedUser();
    	
    	this.projectValidator.validate(project, projectBindingResult);
    	if(!projectBindingResult.hasErrors()) {
    		project.setOwner(loggedUser);
    		this.projectService.saveProject(project);
    		return "redirect:/projects/" + project.getId();
    	}
    	model.addAttribute("loggedUser", loggedUser);
    	return "addProject";
    }
    
    @RequestMapping(value = { "/admin/users" }, method = RequestMethod.GET)
    public String userList(Model model) {
    	
    	User loggedUser = sessionData.getLoggedUser();
    	List<Credentials> allCredentials = this.credentialsService.getAllCredentials();
    	
    	model.addAttribute("loggedUser", loggedUser);
    	model.addAttribute("credentialsList", allCredentials);
    	
    	return "allUsers";
    }
    
    
    @RequestMapping(value = { "/admin/users/{username}/delete" }, method = RequestMethod.POST)
    //dal momento che troviamo un parametro "{username}", allora aggiungiamo @PathVariable
    public String removeUser(Model model, @PathVariable String username) {
    	this.credentialsService.deleteCredentials(username);
    	return "redirect:/admin/users";
    }
    
    
    


}
